-- MySQL dump 10.13  Distrib 8.4.5, for Linux (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	8.4.5

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `expenses`
--

DROP TABLE IF EXISTS `expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `expenses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `expense_date` date NOT NULL,
  `expense_item` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expense_cost` decimal(10,2) NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `expenses_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expenses`
--

LOCK TABLES `expenses` WRITE;
/*!40000 ALTER TABLE `expenses` DISABLE KEYS */;
INSERT INTO `expenses` VALUES (1,1,'2025-10-29','Groceries (Nakumatt)',4500.50,NULL,'2025-10-29 06:50:38','2025-10-29 06:50:38'),(2,1,'2025-10-28','Fuel (Super Petrol)',6000.00,NULL,'2025-10-29 06:50:38','2025-10-29 06:50:38'),(3,1,'2025-10-26','Lunch (Restaurant)',2500.00,NULL,'2025-10-29 06:50:38','2025-10-29 06:50:38'),(4,1,'2025-10-19','Clothes (Thika Road Mall)',12000.75,NULL,'2025-10-29 06:50:38','2025-10-29 06:50:38'),(5,1,'2025-10-14','Movie (Cinema)',3500.00,NULL,'2025-10-29 06:50:38','2025-10-29 06:50:38'),(6,1,'2025-10-27','Matatu Fare',400.00,NULL,'2025-10-29 06:50:38','2025-10-29 06:50:38'),(7,1,'2025-10-24','Airtime & Data',1000.00,NULL,'2025-10-29 06:50:38','2025-10-29 06:50:38');
/*!40000 ALTER TABLE `expenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblexpense`
--

DROP TABLE IF EXISTS `tblexpense`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblexpense` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `UserId` int NOT NULL,
  `ExpenseDate` date DEFAULT NULL,
  `ExpenseItem` varchar(200) DEFAULT NULL,
  `ExpenseCost` varchar(200) DEFAULT NULL,
  `NoteDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblexpense`
--

LOCK TABLES `tblexpense` WRITE;
/*!40000 ALTER TABLE `tblexpense` DISABLE KEYS */;
INSERT INTO `tblexpense` VALUES (1,1,'2024-08-15','Milk','50','2025-10-27 09:19:22'),(2,1,'2024-08-16','Milk+Bread','150','2025-10-27 09:19:22'),(3,1,'2024-08-14','Sugar, Cornflex','456','2025-10-27 09:19:22'),(4,2,'2024-07-30','Cloths','1250','2025-10-27 09:19:22'),(5,2,'2024-06-06','Mobile','12500','2025-10-27 09:19:22'),(6,3,'2024-07-01','Headphones','399','2025-10-27 09:19:22'),(7,3,'2024-07-31','Grocery item','4520','2025-10-27 09:19:22'),(8,3,'2024-08-15','Electricity Bill','1452','2025-10-27 09:19:22'),(9,3,'2024-07-30','Broadband Bill','1180','2025-10-27 09:19:22'),(10,3,'2024-08-16','Bread, Milk, Paneer','150','2025-10-27 09:19:22');
/*!40000 ALTER TABLE `tblexpense` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbluser`
--

DROP TABLE IF EXISTS `tbluser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbluser` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `FullName` varchar(150) DEFAULT NULL,
  `Email` varchar(200) DEFAULT NULL,
  `MobileNumber` bigint DEFAULT NULL,
  `Password` varchar(200) DEFAULT NULL,
  `RegDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbluser`
--

LOCK TABLES `tbluser` WRITE;
/*!40000 ALTER TABLE `tbluser` DISABLE KEYS */;
INSERT INTO `tbluser` VALUES (1,'Rahul','rahul@test.com',1414256320,'f925916e2754e5e03f75dd58a5733251','2025-10-27 09:19:22'),(2,'John Doe','johndoe12@gmail.com',1231231230,'f925916e2754e5e03f75dd58a5733251','2025-10-27 09:19:22'),(3,'Test User','testuser@gmail.com',1233211230,'f925916e2754e5e03f75dd58a5733251','2025-10-27 09:19:22');
/*!40000 ALTER TABLE `tbluser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `full_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile_number` bigint DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `token_expires_at` timestamp NULL DEFAULT NULL,
  `email_verified` tinyint(1) DEFAULT '0',
  `verification_token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Test User','testuser@gmail.com',712345678,'f925916e2754e5e03f75dd58a5733251',NULL,NULL,1,NULL,'2025-10-29 06:50:38','2025-10-29 06:50:38'),(2,'Harrison Ng\'ang\'a','ngangaharrison490@gmail.com',768883913,'e10adc3949ba59abbe56e057f20f883e',NULL,NULL,1,NULL,'2025-10-29 07:21:29','2025-10-29 07:21:29'),(3,'Harrison Ng\'ang\'a','ngangaharrison54@gmail.com',768883913,'e10adc3949ba59abbe56e057f20f883e',NULL,NULL,1,NULL,'2025-10-29 07:26:51','2025-10-29 07:26:51');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-29 12:24:52
